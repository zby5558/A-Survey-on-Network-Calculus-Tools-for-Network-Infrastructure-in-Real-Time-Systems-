package implementation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.networkcalculus.dnc.AnalysisConfig;
import org.networkcalculus.dnc.AnalysisConfig.ArrivalBoundMethod;
import org.networkcalculus.dnc.AnalysisConfig.MaxScEnforcement;
import org.networkcalculus.dnc.AnalysisConfig.MultiplexingEnforcement;
import org.networkcalculus.dnc.network.server_graph.Flow;
import org.networkcalculus.dnc.network.server_graph.Server;
import org.networkcalculus.dnc.network.server_graph.ServerGraph;
import org.networkcalculus.dnc.numbers.Num;
import org.networkcalculus.dnc.tandem.analyses.PmooAnalysis;
import org.networkcalculus.dnc.tandem.analyses.SeparateFlowAnalysis;
import org.networkcalculus.dnc.tandem.analyses.TotalFlowAnalysis;

public class Analysis4to20 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		double[] res1 = new double[21];// results for tfa, sfa and PMOO
		double[] res2 = new double[21];
		double[] res3 = new double[21];
		
		for(int i=1;i<21;i++) { // i is the number of servers in the network
			Four2TwentyTandem_ServerGraph network_factory = new Four2TwentyTandem_ServerGraph(i); // create the network with i servers
			ServerGraph network = network_factory.getServerGraph();
			Set<Flow> s = new HashSet<>();
			s = network.getFlows();
			List<Flow> l = new ArrayList<>(s);
			Flow fol = null;
			for(int j=0;j<l.size();j++) {// find the flow of interest which is defined in the server graph file
				if(l.get(j).getAlias() == "fol") {
					fol = l.get(j);
				}
			}
			Set<ArrivalBoundMethod> arrival_bound_methods = new HashSet<ArrivalBoundMethod>(Collections.singleton(ArrivalBoundMethod.AGGR_PBOO_CONCATENATION));
			AnalysisConfig configuration = new AnalysisConfig(MultiplexingEnforcement.GLOBAL_FIFO,MaxScEnforcement.SERVER_LOCAL,MaxScEnforcement.SERVER_LOCAL,arrival_bound_methods, true,false);
			TotalFlowAnalysis tfa = new TotalFlowAnalysis(network,configuration);
			SeparateFlowAnalysis sfa = new SeparateFlowAnalysis(network,configuration); 
			PmooAnalysis pmoo = new PmooAnalysis(network);// create analyzers for SFA, TFA, and PMOO
			pmoo.performAnalysis(fol);
			tfa.performAnalysis(fol);
			sfa.performAnalysis(fol); //analyze the flow of interest using three methods
			Num restfa = tfa.getDelayBound();
			Num ressfa = sfa.getDelayBound();
			Num respmoo = pmoo.getDelayBound(); // get the delay bound of the flow of interest
			res1[i] = restfa.doubleValue();
			res2[i] = ressfa.doubleValue();
			res3[i] = respmoo.doubleValue();
			
		}
		
//		for(int i=1;i<21;i++) {
//			System.out.println(res2[i]);
//			//System.out.println(res2[i]);
//			//System.out.println(res3[i]);
//		}
//		XYSeries series1 = new XYSeries("tfa");
//		for (int x = 1; x <= 20; x++) {
//			double y1 = res1[x-1].doubleValue();
//			series1.add(x, y1);
//			//series.add(x, y2);
//		}
//		XYSeries series2 = new XYSeries("sfa");
//		for (int x = 1; x <= 20; x++) {
//			double y2 = res2[x-1].doubleValue();
//			series2.add(x, y2);
//			//series.add(x, y2);
//		}
//		XYSeries series3 = new XYSeries("pmoo");
//		for (int x = 1; x <= 20; x++) {
//			double y3 = res3[x-1].doubleValue();
//			series3.add(x, y3);
//			//series.add(x, y2);
//		}
//		XYSeriesCollection dataset = new XYSeriesCollection();
//		dataset.addSeries(series1);
//		dataset.addSeries(series2);
//		dataset.addSeries(series3);
//		JFreeChart chart = ChartFactory.createXYLineChart(
//				"tfa, sfa", // chart title
//				"nodes", // x axis label
//				"delay", // y axis label
//				dataset, // data
//				PlotOrientation.VERTICAL,
//				true, // include legend
//				false, // tooltips
//				false // urls
//				);
// 
//		ChartFrame frame = new ChartFrame("my picture", chart);
//		frame.pack();
//		frame.setVisible(true);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//System.out.println(res1.toString());
		//System.out.print(res2.toString());

	}

}
