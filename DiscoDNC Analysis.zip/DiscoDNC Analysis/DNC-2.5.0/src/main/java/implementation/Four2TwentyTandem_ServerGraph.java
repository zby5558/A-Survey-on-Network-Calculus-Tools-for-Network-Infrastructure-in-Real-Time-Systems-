
package implementation;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.networkcalculus.dnc.curves.ArrivalCurve;
import org.networkcalculus.dnc.curves.Curve;
import org.networkcalculus.dnc.curves.ServiceCurve;
import org.networkcalculus.dnc.network.server_graph.Flow;
import org.networkcalculus.dnc.network.server_graph.Server;
import org.networkcalculus.dnc.network.server_graph.ServerGraph;
import org.networkcalculus.dnc.network.server_graph.ServerGraphFactory;
import org.networkcalculus.dnc.network.server_graph.Turn;

public class Four2TwentyTandem_ServerGraph implements ServerGraphFactory{
	private final int sc_R = 1000;
	private final double sc_T =  0.001;
	private final double ac_r = 0.008;
	private final double ac_b = 2;
	
	private Server[] sl = new Server[21]; // array to store nodes, the maximum number of servers is 21
	private Turn[] tl = new Turn[20]; // array to store links between servers, since it i a tandem network, 21 servers only have 20 links
	
	private ServiceCurve service_curve = Curve.getFactory().createRateLatency(sc_R, sc_T); // create the service curve	
	private ArrivalCurve arrival_curve = Curve.getFactory().createTokenBucket(ac_r, ac_b); // create the arrival curve
//	private ArrivalCurve arrival_curve1 = Curve.getFactory().createTokenBucket(3*ac_r, 5*ac_b);
//	private ArrivalCurve arrival_curve2 = Curve.getFactory().createTokenBucket(5*ac_r, 10*ac_b);
	private ServerGraph server_graph;

	public Four2TwentyTandem_ServerGraph(int i) {
		server_graph = createServerGraph(i); // create the network with i servers
	}

	public ServerGraph getServerGraph() {
		return server_graph;
	}

	public ServerGraph createServerGraph(int i) {
		server_graph = new ServerGraph();
		if(i == 1) { // the condition that there is only one servers
			sl[0] = server_graph.addServer(service_curve); //there is only
			try {
				server_graph.addFlow("f1", arrival_curve, sl[0]);
				server_graph.addFlow("fol", arrival_curve, sl[0]);
				server_graph.addFlow("f2", arrival_curve, sl[0]);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return server_graph;
		}
		for(int j=0;j<i;j++) {
			sl[j]  =  server_graph.addServer(service_curve);
		}

		try {
			for(int j=0;j<i-1;j++) {
				tl[j] = server_graph.addTurn(sl[j],sl[j+1]);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		List<Turn> fol = new LinkedList<>();
		for(int j=0;j<i-1;j++) {
			fol.add(tl[j]);
		}

		try {
			for(int j=0;j<i-1;j++) { // add flows to the network
				String alias = "f"+j;
				//System.out.println(alias);
				LinkedList<Turn> path = new LinkedList<Turn>();
				path.add(tl[j]);
				server_graph.addFlow(alias, arrival_curve, path);
			}
			server_graph.addFlow("source", arrival_curve, sl[0]);
			server_graph.addFlow("des", arrival_curve, sl[i-1]);
			server_graph.addFlow("fol", arrival_curve, fol);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}

		return server_graph;
	}

	public void reinitializeCurves() {
		service_curve = Curve.getFactory().createRateLatency(sc_R, sc_T);
		for (Server server : server_graph.getServers()) {
			server.setServiceCurve(service_curve);
		}

		arrival_curve = Curve.getFactory().createTokenBucket(ac_r, ac_b);
		for (Flow flow : server_graph.getFlows()) {
			flow.setArrivalCurve(arrival_curve);
		}
	}

	@Override
	public ServerGraph createServerGraph() {
		// TODO Auto-generated method stub
		return null;
	}

}
