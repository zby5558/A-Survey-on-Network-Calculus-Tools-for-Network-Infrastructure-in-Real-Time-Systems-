import org.networkcalculus.dnc.network.server_graph.ServerGraph;

public class ff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerGraph sG = new ServerGraph();

	}

}
